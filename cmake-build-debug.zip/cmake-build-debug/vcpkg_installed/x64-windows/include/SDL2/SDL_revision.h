/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-2.28.4-no-vcs (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-2.28.4-no-vcs"
#endif
